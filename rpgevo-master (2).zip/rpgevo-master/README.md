RPG Evolution

You start in a choose your own adventure.

You get two choices.

And another two.

And yet another.

But after a while...

More choices start popping up.

Then, after another while...

Out of the blue...

GRAPHICS!

You can see!

And what's this?

This world is getting more and more...

Freeform!

Moving!

Different attacks!

HP!

You're having a lot of fun now, who could have thought?

This is a public repository, so anyone can submit a pull request. Therefore, this is a game that anyone can submit changes and ideas to.
