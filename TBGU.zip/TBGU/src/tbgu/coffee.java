/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tbgu;

/**
 *
 * @author s-millerel
 */
public class coffee {
    static double temp;
    static boolean caff;
    static boolean ice;
    public coffee(double inTemp, boolean inCaff, boolean inIce){
        temp=inTemp;
        caff=inCaff;
        ice=inIce;
    }
    public static void heat(double amtInc){
        temp+=amtInc;
        System.out.println("You heated the coffee. The temperature is now "+temp);
    }
    public static void addIce(){
        temp-=20;
        ice=true;
        System.out.println("You added ice to the coffee. The temperature is now "+temp);
    }
}